package newpackage;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyClass {

public static void main(String[] args) throws InterruptedException {

// declaration and instantiation of objects/variables
System.setProperty("webdriver.chrome.driver", "E:\\selenuim\\chromedriver.exe");

// Chrome web driver initialize
WebDriver driver=new ChromeDriver();

//open page
driver.navigate().to("https://the-internet.herokuapp.com/javascript_alerts");

//Assignment 1: To handle Pop-up

	//for handling alert box
driver.findElement(By.xpath("//button[@onclick='jsAlert()']")).click();
Thread.sleep(2000);
driver.switchTo().alert().accept();
Thread.sleep(2000);

//for handling confirm box -> dismiss
driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
Thread.sleep(2000);
driver.switchTo().alert().dismiss();
Thread.sleep(2000);

//for handling confirm box -> accept
driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
Thread.sleep(2000);
driver.switchTo().alert().accept();
Thread.sleep(2000);

//for handling prompt box
driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();
Thread.sleep(2000);
driver.switchTo().alert().sendKeys("Amol Gadage");
Thread.sleep(2000);
driver.switchTo().alert().accept();
Thread.sleep(2000);


//Assignment 2: To handle nested iFrames
//open url
driver.get("https://the-internet.herokuapp.com/iframe");

//switch to first iFrame
driver.switchTo().frame(0);
Thread.sleep(2000);

//clear body content in the iFrame
driver.findElement(By.id("tinymce")).clear();
Thread.sleep(2000);

//enter new data to body in the iFrame
driver.findElement(By.id("tinymce")).sendKeys("I am now here!!");
Thread.sleep(2000);

 

}

}
